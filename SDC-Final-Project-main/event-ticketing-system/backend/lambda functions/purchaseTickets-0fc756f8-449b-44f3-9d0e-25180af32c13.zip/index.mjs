import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  QueryCommand,
  GetCommand,
  PutCommand,
  DeleteCommand
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: "us-east-1" });
const ddb = DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});

export const handler = async (event) => {
  console.log("purchaseTickets event:", JSON.stringify(event, null, 2));

  const response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true
    }
  };

  try {
    const body = event.body ? JSON.parse(event.body) : event;
    const { userId } = body;

    if (!userId) {
      response.statusCode = 400;
      response.body = JSON.stringify({
        success: false,
        message: "userId is required"
      });
      return response;
    }

    // 1️⃣ Get all cart items for user
    const cartResult = await ddb.send(
      new QueryCommand({
        TableName: "CartTable2",
        KeyConditionExpression: "userId = :uid",
        ExpressionAttributeValues: {
          ":uid": userId
        }
      })
    );

    const cartItems = cartResult.Items || [];

    if (cartItems.length === 0) {
      response.statusCode = 400;
      response.body = JSON.stringify({
        success: false,
        message: "Cart is empty"
      });
      return response;
    }

    // 2️⃣ Build tickets array using prices from TicketInventory
    const tickets = [];
    let totalAmount = 0;

    for (const item of cartItems) {
      const inventoryResult = await ddb.send(
        new GetCommand({
          TableName: "TicketInventory",
          Key: { ticketType: item.ticketType }
        })
      );

      if (!inventoryResult.Item) {
        throw new Error(`Ticket type not found: ${item.ticketType}`);
      }

      const price = inventoryResult.Item.price;
      const totalPrice = price * item.quantity;

      tickets.push({
        ticketType: item.ticketType,
        quantity: item.quantity,
        price,
        totalPrice
      });

      totalAmount += totalPrice;
    }

    // 3️⃣ Create order
    const orderId =
      "TS-" + Math.random().toString(36).substring(2, 10).toUpperCase();

    const purchaseTime = Date.now();

    await ddb.send(
      new PutCommand({
        TableName: "OrdersTable",
        Item: {
          orderId,
          userId,
          tickets,
          totalAmount,
          purchaseTime,
          status: "completed"
        }
      })
    );

    // 4️⃣ Delete all cart items for user
    for (const item of cartItems) {
      await ddb.send(
        new DeleteCommand({
          TableName: "CartTable2",
          Key: {
            userId: item.userId,
            createdAt: item.createdAt
          }
        })
      );
    }

    response.body = JSON.stringify({
      success: true,
      message: "Purchase completed successfully",
      orderId,
      totalAmount,
      timestamp: new Date(purchaseTime).toISOString()
    });

  } catch (error) {
    console.error("Purchase error:", error);
    response.statusCode = 500;
    response.body = JSON.stringify({
      success: false,
      message: "Failed to complete purchase",
      error: error.message
    });
  }

  return response;
};
