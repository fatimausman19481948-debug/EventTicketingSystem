import { DynamoDBClient, PutItemCommand, ScanCommand } from "@aws-sdk/client-dynamodb";
import crypto from "crypto";

const db = new DynamoDBClient();

export const handler = async (event) => {
  if (event?.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
      },
      body: ""
    };
  }

  const userId = crypto.randomUUID();
  const now = Date.now();

  const scan = await db.send(new ScanCommand({ TableName: "QueueTable" }));
  const position = scan.Count + 1;

  await db.send(new PutItemCommand({
    TableName: "QueueTable",
    Item: {
      userId: { S: userId },
      joinedAt: { N: `${now}` },
      status: { S: "WAITING" }
    }
  }));

  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    },
    body: JSON.stringify({ userId, position })
  };
};
