import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";

const db = new DynamoDBClient({ region: "us-east-1" });

export const handler = async (event) => {
  // Handle CORS preflight
  if (event?.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET,OPTIONS"
      },
      body: ""
    };
  }

  try {
    const result = await db.send(
      new ScanCommand({
        TableName: "TicketInventory"
      })
    );

    // Default response (prevents undefined issues)
    const inventory = {
      general: 0,
      vip: 0,
      student: 0
    };

    // Map DynamoDB items → frontend shape
    result.Items.forEach(item => {
      const type = item.ticketType.S;
      const available = Number(item.available.N);

      inventory[type] = available;
    });

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET,OPTIONS"
      },
      body: JSON.stringify(inventory)
    };

  } catch (error) {
    console.error("Error fetching inventory:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Failed to get ticket inventory" })
    };
  }
};
