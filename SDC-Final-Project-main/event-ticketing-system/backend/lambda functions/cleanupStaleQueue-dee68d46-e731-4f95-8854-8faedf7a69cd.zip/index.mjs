import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  DeleteCommand,
  ScanCommand
} from "@aws-sdk/lib-dynamodb";

// Initialize DynamoDB client
const client = new DynamoDBClient({ region: "us-east-1" });
const ddb = DynamoDBDocumentClient.from(client); // ✅ this was miss
export const handler = async () => {
  try {
    console.log('Cleanup function started at:', new Date().toISOString());
    
    // 1️⃣ Get all users from the queue
    const queueData = await ddb.send(
      new ScanCommand({ TableName: "QueueTable" })
    );

    const users = queueData.Items || [];
    console.log(`Total users in queue: ${users.length}`);
    
    // Log all waiting users
    const waitingUsers = users.filter(u => (u.status || '').toLowerCase() === 'waiting');
    console.log('Waiting users:', waitingUsers.map(u => ({
      userId: u.userId,
      status: u.status,
      lastSeen: u.lastSeen,
      lastSeenDate: u.lastSeen ? new Date(Number(u.lastSeen)).toISOString() : null,
      ageMinutes: u.lastSeen ? Math.floor((Date.now() - Number(u.lastSeen)) / 60000) : null
    })));

    // 2️⃣ Filter users with status "waiting" and stale lastSeen (>5 min)
    const now = Date.now();
    const staleWaitingUsers = users.filter(
      (user) => {
        const status = (user.status || '').toLowerCase();
        const isWaiting = status === 'waiting';
        const hasLastSeen = !!user.lastSeen;
        const lastSeenNum = Number(user.lastSeen);
        const ageMs = now - lastSeenNum;
        const isStale = ageMs > 5 * 60 * 1000;
        
        if (isWaiting && hasLastSeen) {
          console.log(`User ${user.userId}: status=${status}, lastSeen=${lastSeenNum}, ageMs=${ageMs}, isStale=${isStale}`);
        }
        
        return isWaiting && hasLastSeen && isStale;
      }
    );

    console.log(`Found ${staleWaitingUsers.length} stale waiting users`);
    
    // 3️⃣ Remove each stale waiting user
    for (const user of staleWaitingUsers) {
      if (!user.userId) continue;

      console.log(`Removing stale user ${user.userId} with lastSeen: ${user.lastSeen} (${new Date(Number(user.lastSeen)).toISOString()})`);

      // Delete from QueueTable
      await ddb.send(
        new DeleteCommand({
          TableName: "QueueTable",
          Key: { userId: user.userId }
        })
      );

      // Delete from CartTable if exists

      console.log(`Removed stale waiting user: ${user.userId}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: `Cleaned ${staleWaitingUsers.length} stale waiting users`,
        details: {
          totalUsers: users.length,
          waitingUsers: waitingUsers.length,
          staleUsers: staleWaitingUsers.length
        }
      })
    };
  } catch (err) {
    console.error("cleanupStaleQueue error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        message: "Failed to clean stale waiting users",
        error: err.message,
        stack: err.stack 
      })
    };
  }
};