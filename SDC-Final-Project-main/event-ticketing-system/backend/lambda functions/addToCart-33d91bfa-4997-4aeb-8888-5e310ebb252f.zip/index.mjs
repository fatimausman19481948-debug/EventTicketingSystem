import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  UpdateCommand,
  PutCommand
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const ddb = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  // CORS headers
  const responseHeaders = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true
  };

  try {
    const body = JSON.parse(event.body);
    const { userId, ticketType, quantity } = body;

    if (!userId || !ticketType || !quantity) {
      return {
        statusCode: 400,
        headers: responseHeaders,
        body: JSON.stringify({ message: "Missing required fields" })
      };
    }

    // Get inventory
    const inventory = await ddb.send(
      new GetCommand({
        TableName: "TicketInventory",
        Key: { ticketType }
      })
    );

    if (!inventory.Item || inventory.Item.available < quantity) {
      return {
        statusCode: 400,
        headers: responseHeaders,
        body: JSON.stringify({ message: "Not enough tickets available" })
      };
    }

    // Atomically decrement inventory
    await ddb.send(
      new UpdateCommand({
        TableName: "TicketInventory",
        Key: { ticketType },
        UpdateExpression: "SET available = available - :q",
        ConditionExpression: "available >= :q",
        ExpressionAttributeValues: {
          ":q": quantity
        }
      })
    );

    // Save cart item
    await ddb.send(
      new PutCommand({
        TableName: "CartTable2",
        Item: {
          userId,                     // PK
          createdAt: Date.now(),      // Sort key
          ticketType,
          quantity
        }
      })
    );

    return {
      statusCode: 200,
      headers: responseHeaders,
      body: JSON.stringify({ message: "Tickets added to cart successfully" })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: responseHeaders,
      body: JSON.stringify({ message: "Failed to add to cart", error: err.message })
    };
  }
};
