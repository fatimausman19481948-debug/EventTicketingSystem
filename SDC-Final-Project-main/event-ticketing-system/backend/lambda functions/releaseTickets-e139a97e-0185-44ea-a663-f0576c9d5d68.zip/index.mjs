import { DynamoDBClient } from "@aws-sdk/client-dynamodb"; 
import {
  DynamoDBDocumentClient,
  UpdateCommand,
  ScanCommand,
  DeleteCommand
} from "@aws-sdk/lib-dynamodb";

// Create DynamoDB client
const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    console.log('releaseTickets event:', JSON.stringify(event, null, 2));

    // CORS headers
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        }
    };

    try {
        let body;
        if (event.body) {
            body = JSON.parse(event.body);
        } else {
            body = event; // for testing in Lambda console
        }

        const { userId, ticketType, quantity } = body;
        if (!userId || !ticketType || !quantity) {
            response.statusCode = 400;
            response.body = JSON.stringify({ success: false, message: 'userId, ticketType, and quantity are required' });
            return response;
        }

        // 1️⃣ Update inventory: add quantity back
        const updateParams = {
            TableName: 'TicketInventory',
            Key: { ticketType: ticketType },
            UpdateExpression: 'SET available = available + :qty',
            ExpressionAttributeValues: { ':qty': quantity },
            ReturnValues: 'UPDATED_NEW'
        };
        const updateResult = await dynamodb.send(new UpdateCommand(updateParams));
        console.log('Inventory updated:', updateResult);

        // 2️⃣ Scan CartTable to find items to delete
        const scanResult = await dynamodb.send(new ScanCommand({
            TableName: 'CartTable2',
            FilterExpression: 'userId = :uid AND ticketType = :type',
            ExpressionAttributeValues: {
                ':uid': userId,
                ':type': ticketType
            }
        }));

        if (scanResult.Items && scanResult.Items.length > 0) {
            for (const item of scanResult.Items) {
                await dynamodb.send(new DeleteCommand({
                    TableName: 'CartTable2',
                    Key: {
                        userId: item.userId,
                        createdAt: item.createdAt
                    }
                }));
            }
        }

        response.body = JSON.stringify({
            success: true,
            message: `Released ${quantity} ${ticketType} tickets for user ${userId}`,
            updatedInventory: updateResult.Attributes.available,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Error releasing tickets:', error);
        response.statusCode = 500;
        response.body = JSON.stringify({
            success: false,
            message: 'Failed to release tickets',
            error: error.message
        });
    }

    return response;
};
