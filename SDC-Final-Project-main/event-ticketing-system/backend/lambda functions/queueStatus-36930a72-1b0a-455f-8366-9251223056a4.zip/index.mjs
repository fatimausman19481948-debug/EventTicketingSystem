import { DynamoDBClient, ScanCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";

// Initialize DynamoDB client
const db = new DynamoDBClient({ region: "us-east-1" });

export const handler = async (event) => {
  if (event?.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
      },
      body: ""
    };
  }

  try {
    const userId = event?.queryStringParameters?.userId;
    if (!userId) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" }, // ✅ add here
        body: JSON.stringify({ error: "Missing userId" }),
      };
    }

    const scanResult = await db.send(new ScanCommand({ TableName: "QueueTable" }));
    const sorted = scanResult.Items.sort(
      (a, b) => Number(a.joinedAt.N) - Number(b.joinedAt.N)
    );

    const index = sorted.findIndex(i => i.userId.S === userId);

    if (index === -1) {
      return {
        statusCode: 404,
        headers: { "Access-Control-Allow-Origin": "*" }, // ✅ add here
        body: JSON.stringify({ error: "User not found in queue" }),
      };
    }
    if (index > 0) {
      await db.send(new UpdateItemCommand({
        TableName: "QueueTable",
        Key: { userId: { S: userId } },
        UpdateExpression: "SET lastSeen = :now",
        ExpressionAttributeValues: { ":now": { N: Date.now().toString() } }
      }));
    }
    if (index === 0) {
      const nowInSeconds = Math.floor(Date.now() / 1000);
      const ttlInSeconds = nowInSeconds + 5 * 60;
      await db.send(new UpdateItemCommand({
        TableName: "QueueTable",
        Key: { userId: { S: userId } },
        UpdateExpression: "SET #s = :a, #e = :expires",
        ExpressionAttributeNames: { "#s": "status", "#e": "expiresAt" },
        ExpressionAttributeValues: { 
            ":a": { S: "ALLOWED" },
            ":expires": { N: ttlInSeconds.toString() }  // TTL in seconds
        },
      }));

      return {
        statusCode: 200,
        headers: { "Access-Control-Allow-Origin": "*" }, // ✅ add here
        body: JSON.stringify({ status: "ALLOWED" }),
      };
    }

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" }, // ✅ add here
      body: JSON.stringify({
        userId,
        status: "WAITING",
        position: index + 1,
      }),
    };

  } catch (err) {
    console.error("Error in handler:", err);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Internal server error" }),
    };
  }
};
